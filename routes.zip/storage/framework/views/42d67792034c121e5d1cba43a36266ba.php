

<?php $__env->startSection('title', 'Pengalaman - CV Pribadi'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $fullName = $biodata?->full_name ?? 'Saya';
?>

<!-- Hero Section -->
<div class="relative hero-gradient-warm-animated text-white py-24 md:py-32 overflow-hidden">
    <!-- Animated Pattern Overlay -->
    <div class="absolute inset-0 hero-pattern-animated opacity-30"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <p class="text-lg font-semibold text-white uppercase tracking-wider mb-4 fade-in-up">Aktivitas & Proyek</p>
        <h1 class="text-5xl md:text-6xl font-display font-bold mb-6 text-white fade-in-up stagger-1">Pengalaman</h1>
        <p class="text-xl text-white/90 max-w-2xl mx-auto fade-in-up stagger-2">Organisasi, magang, dan proyek</p>
    </div>
</div>

<!-- Work Experience Section -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
    <div class="section-header fade-in-up">
        <h2 class="text-gray-900 dark:text-gray-100">Riwayat Pengalaman</h2>
        <div class="divider bg-gradient-to-r from-transparent via-purple-500 dark:via-purple-400 to-transparent"></div>
        <p class="text-gray-600 dark:text-gray-400">Organisasi, magang, dan tugas proyek</p>
    </div>

    <div class="space-y-8" data-stagger>
        <?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                try {
                    $start = $experience->start_date ? \Carbon\Carbon::parse($experience->start_date)->format('M Y') : null;
                    $end = $experience->end_date ? \Carbon\Carbon::parse($experience->end_date)->format('M Y') : 'Sekarang';
                } catch (\Exception $e) {
                    $start = null;
                    $end = 'Sekarang';
                }
            ?>
            <div class="modern-card card-hover overflow-hidden fade-in-up bg-white dark:bg-gray-800 border dark:border-gray-700 transition-colors duration-300">
                <div class="md:flex">
                    <div class="md:w-1/4 bg-gradient-to-br from-purple-600 to-purple-700 dark:from-purple-700 dark:to-purple-800 p-6 text-white">
                        <div class="text-center space-y-2">
                            <div class="bg-white/20 rounded-lg p-4">
                                <svg class="w-12 h-12 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                                    <path d="M13 7H7a2 2 0 00-2 2v6h10V9a2 2 0 00-2-2z"/>
                                    <path fill-rule="evenodd" d="M6 3a1 1 0 011-1h1.382a1 1 0 01.894.553L10 4h3a1 1 0 011 1v1H6V3z" clip-rule="evenodd"/>
                                </svg>
                            </div>
                            <p class="text-sm font-semibold"><?php echo e($start ?? '-'); ?> &mdash; <?php echo e($end); ?></p>
                            <?php if($experience->is_current): ?>
                                <span class="px-3 py-1 text-xs font-semibold bg-green-500 rounded-full">Sedang Berjalan</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="md:w-3/4 p-6 space-y-4">
                        <div>
                            <h3 class="text-2xl font-bold text-gray-800 dark:text-gray-100"><?php echo e($experience->position); ?></h3>
                            <p class="text-purple-600 dark:text-purple-400 font-semibold"><?php echo e($experience->company); ?></p>
                            <?php if($experience->location): ?>
                                <p class="text-gray-500 dark:text-gray-400 text-sm"><?php echo e($experience->location); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php if($experience->description): ?>
                            <p class="text-gray-700 dark:text-gray-300 leading-relaxed"><?php echo nl2br(e($experience->description)); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="modern-card text-center py-12 fade-in-up bg-white dark:bg-gray-800 border dark:border-gray-700">
                <h3 class="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-2">Belum ada data pengalaman</h3>
                <p class="text-gray-500 dark:text-gray-400">Tambahkan pengalaman di basis data untuk menampilkan riwayat pekerjaan dan proyek.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- CTA Section -->
<div class="bg-gradient-to-r from-purple-600 to-pink-600 dark:from-purple-700 dark:to-pink-700 py-20 text-white relative overflow-hidden">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 fade-in-up">
        <h2 class="text-3xl md:text-4xl font-bold mb-4">Lihat Halaman Lainnya</h2>
        <p class="text-lg md:text-xl mb-8 text-purple-100 dark:text-purple-200">
            Jelajahi riwayat pendidikan dan keahlian teknis saya
        </p>
        <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center justify-center px-8 py-3 bg-white text-purple-600 rounded-xl font-semibold hover:bg-purple-50 transition shadow-lg">
                Kembali ke Home
            </a>
            <a href="<?php echo e(route('skills')); ?>" class="inline-flex items-center justify-center px-8 py-3 bg-white/10 backdrop-blur-sm text-white rounded-xl font-semibold hover:bg-white/20 transition border-2 border-white/30">
                Lihat Keahlian
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\LaravelCV\resources\views/experience.blade.php ENDPATH**/ ?>